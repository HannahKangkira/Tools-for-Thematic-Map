﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public static Dictionary<int, string> city_dic = new Dictionary<int, string>();
        public static Dictionary<int, double> popu_dic = new Dictionary<int, double>();
        public static int quant;
        public static int divide;
        public static double[] num_A = new double[100];
        public static int city_index = 0;
        public static int num_index = 0;
        

        public Form1()
        {
            InitializeComponent();
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            //SoundPlayer sp = new SoundPlayer();
            //sp.SoundLocation = "meow.wav";
            //sp.Play();
            if (city_index==num_index && city_index!=0 && num_index != 0 &&numericUpDown1.Value >1)
            {
                if (radioButton1.Checked == true)
                {
                    Bubble_sort();
                    common Meow = new common();
                    Meow.H = getmax();
                    Meow.L = getmin();
                    divide = Convert.ToInt32(numericUpDown1.Value) - 1;
                    for (int i = 0; i < divide; i++)
                    {
                        num_A[i] = Meow.L + (i + 1) * Meow.get_n(Meow.L, Meow.H, divide);
                    }
                    label5.Text = ("等差数列分档结果：");
                    label6.Text = ("等差数列分档标准：");
                    label7.Text = output_standard();
                    label4.Text = draw_divide();
                }
                else if (radioButton2.Checked == true)
                {
                    Bubble_sort();
                    common Meow = new common();
                    Meow.H = getmax();
                    Meow.L = getmin();
                    divide = Convert.ToInt32(numericUpDown1.Value) - 1;
                    double temp_double = 0;
                    double temp_double_2 = 0;
                    for (int i = 0; i < divide; i++)
                    {
                        temp_double = (double)(i + 1);
                        temp_double_2 = (double)(divide + 1);
                        num_A[i] = getmin() * Math.Pow((getmax() / getmin()), temp_double / temp_double_2);
                    }
                    label5.Text = ("等比数列分级分档结果：");
                    label6.Text = ("等比数列分档标准：");
                    label7.Text = output_standard();
                    label4.Text = draw_divide();
                }
                else if (radioButton3.Checked == true)
                {
                    label5.Text = ("输入的数据列表");
                    label4.Text = show_data();
                }
                else
                {
                    MessageBox.Show("请检查你的选中项是否合法！");
                    radioButton1.Checked = false;
                    radioButton2.Checked = false;
                    radioButton3.Checked = false;
                }
               
            }
            else
            {
                MessageBox.Show("输入数量不一致，或分级数量过少无法分级 \n 请检查你的输入！");
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //SoundPlayer sp = new SoundPlayer();
            //sp.SoundLocation = "meow.wav";
            //sp.Play();
            MessageBox.Show("作者：康祯恒 \t \n 2022年4月\t");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //SoundPlayer sp = new SoundPlayer();
            //sp.SoundLocation = "meow.wav";
            //sp.Play();
            if (textBox1.Text !="")
            {
                string name = textBox1.Text;
                city_dic.Add(city_index, name);
                city_index++;
                textBox1.ResetText();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //SoundPlayer sp = new SoundPlayer();
            //sp.SoundLocation = "meow.wav";
            //sp.Play();
            if (textBox2.Text != "")
            {
                try
                {
                    double popu = Convert.ToDouble(textBox2.Text);
                    popu_dic.Add(num_index, popu);
                    num_index++;
                    textBox2.ResetText();
                }
                catch
                {
                    MessageBox.Show("请输入正确的值！");
                    textBox2.ResetText();
                }
            }
        }
        public static string show_data()
        {
            string compo_text_1 = "";
            for (int i = 0; i < city_index; i++)
            {
                compo_text_1 += city_dic[i]; compo_text_1 += "============"; compo_text_1 += popu_dic[i];
                compo_text_1 += "\n";
            }
            return compo_text_1;

        }
        //冒泡排序，将字典中的记录排序
        public static void Bubble_sort()
        {
            double temp;
            string temp_str;
            bool swapped;
            for (int i = 0; i < city_index; i++)
            {
                swapped = false;
                for (int j = 0; j < city_index - 1 - i; j++)
                    if (popu_dic[j] > popu_dic[j + 1])
                    {
                        temp = popu_dic[j];
                        temp_str = city_dic[j];
                        popu_dic[j] = popu_dic[j + 1];
                        city_dic[j] = city_dic[j + 1];
                        popu_dic[j + 1] = temp;
                        city_dic[j + 1] = temp_str;
                        if (!swapped)
                            swapped = true;
                    }
                if (!swapped)
                    return;
            }
        }
        //获得分类对象中的最小值
        public static double getmin()
        {
            double min;
            min = popu_dic[0];
            for (int i = 0; i < city_index; i++)
            {
                if (min > popu_dic[i])
                {
                    min = popu_dic[i];
                }
            }
            return min;
        }
        //获得分类对象中的最大值
        public static double getmax()
        {
            double max;
            max = popu_dic[0];
            for (int i = 0; i < city_index; i++)
            {
                if (max < popu_dic[i])
                {
                    max = popu_dic[i];
                }
            }
            return max;
        }
        //输出分级模块
        public static string output_standard()
        {
            string compo_text_1 = "";
            
            compo_text_1 += "第1档 <="; compo_text_1 += Math.Round(num_A[0], 3);
            compo_text_1 += "\n";
            for (int i = 0; i + 1 <= divide - 1; i++)
            {
                
                compo_text_1 += "第";compo_text_1 += i + 2; compo_text_1 += "档"; compo_text_1 += Math.Round(num_A[i], 3);
                compo_text_1 += "~"; compo_text_1 += Math.Round(num_A[i + 1], 3);
                compo_text_1 += "\n";
            }
            
            compo_text_1 += "第"; compo_text_1 += divide + 1; compo_text_1 += "档>"; compo_text_1 += Math.Round(num_A[divide - 1], 3);
            compo_text_1 += "\n";

            return compo_text_1.ToString();
        }
        //输出分级标准与划分
        public static string draw_divide()
        {
            int j = 0;
            int i = 0;
            string compo_text_1 = "";
            while (j <= city_index+1 && i <= divide)
            {
                if (popu_dic[j] > num_A[i])
                {
                    i++;
                    if (i == divide)
                    {
                        while (j < city_index)
                        {
                            //compo_text_1+=("{0}============{1}", city_dic[j], popu_dic[j]).ToString();
                            compo_text_1 += city_dic[j]; compo_text_1 += "============"; compo_text_1 += popu_dic[j];
                            compo_text_1 += "\n";
                            j++;
                        }
                        compo_text_1+=("*********************");
                        compo_text_1 += "\n";
                        break;
                    }
                }
                while (popu_dic[j] < num_A[i])
                {
                    //compo_text_1+=("{0}============{1}", city_dic[j], popu_dic[j]).ToString();
                    compo_text_1 += city_dic[j]; compo_text_1 += "============"; compo_text_1 += popu_dic[j];
                    compo_text_1 += "\n";
                    j++;
                }
                compo_text_1 += ("*********************");
                compo_text_1 += "\n";
            }
            return compo_text_1;
        }
    }
    public class common
    {
        private double _l;
        public double L
        {
            get { return _l; }
            set
            {
                while (true)
                {
                    if (value > 0)
                    {
                        _l = value;
                        break;
                    }
                    else
                    {
                        MessageBox.Show("请重新输入L值！");
                    }

                }
            }
        }

        private double _h;
        public Double H
        {
            get { return _h; }
            set
            {
                while (true)
                {
                    if (value > 0 && value > L)
                    {
                        _h = value;
                        break;
                    }
                    else
                    {
                        MessageBox.Show("输入错误！请重新输入H值！");
                    }

                }
            }
        }
        public double get_n(double _l, double _h, int _k)
        {
            double N = (_h - _l) / (_k + 1);
            return N;
        }
    }
    
}
